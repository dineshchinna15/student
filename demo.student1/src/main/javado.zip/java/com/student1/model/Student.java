package com.student1.model;

import java.util.HashSet;
import java.util.Set;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Data
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Document(collection = "students")
public class Student 
{
	@Id
	private Integer studentId;
	private String studentFirstName;
	private String studentLastName;
	private String studentEmail;
	private Long studentPhoneNo;
	
	
	private Set<Course> courses = new HashSet<>();
	
	
	

}
