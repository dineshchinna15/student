package com.student1.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;
import org.springframework.stereotype.Repository;

import com.student1.model.Student;


@Repository
public interface StudentRepository extends MongoRepository<Student,Integer>{

}
