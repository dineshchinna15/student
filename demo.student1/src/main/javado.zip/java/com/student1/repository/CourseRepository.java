package com.student1.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;
import org.springframework.stereotype.Repository;

import com.student1.model.Course;


@Repository
public interface CourseRepository extends MongoRepository<Course,Integer> 
{

}
