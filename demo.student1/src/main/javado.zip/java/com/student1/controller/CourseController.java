package com.student1.controller;

import java.util.List;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.student1.model.Course;
import com.student1.model.Student;
import com.student1.response.ResponseModel;
import com.student1.service.CourseService;

import ch.qos.logback.classic.Logger;
import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
@RequestMapping("/api/courses")
public class CourseController 
{
	//private static final Logger logger = (Logger) LoggerFactory.getLogger(CourseController.class);
	
	@Autowired
    private CourseService courseService;
	
	
	@PostMapping("/saveCourses")
    public ResponseEntity<ResponseModel<Void>> createCourse(@RequestBody Course course) {
        courseService.saveCourse(course);
        log.info("Course saved successfully");

        ResponseModel<Void> responseModel = new ResponseModel<>();
        responseModel.setStatus(HttpStatus.OK.toString());
        responseModel.setMessage("Course saved successfully");

        return ResponseEntity.ok(responseModel);
    }
    
    @GetMapping("/getAllCourses")
    public ResponseEntity<ResponseModel<List<Course>>> getAllCourses()
    {
    	ResponseModel<List<Course>> model = courseService.getAllCourses();
    	ResponseEntity<ResponseModel<List<Course>>> response = new ResponseEntity<>(model,HttpStatus.OK);
        log.info("courses fetched successfully");
        return response;
    }
    

    @PutMapping("/{courseId}")
    public ResponseEntity<ResponseModel<Void>> updateCourse(@PathVariable Integer courseId,
                                                            @RequestBody Course course) {
        course.setCourseId(courseId);
        courseService.saveCourse(course);
        log.info("Course updated successfully");

        ResponseModel<Void> responseModel = new ResponseModel<>();
        responseModel.setStatus(HttpStatus.OK.toString());
        responseModel.setMessage("Course updated successfully");

        return ResponseEntity.ok(responseModel);
    }
    
    @DeleteMapping("/{courseId}")
    public ResponseEntity<ResponseModel<Void>> deleteCourse(@PathVariable Integer courseId) {
        courseService.deleteCourseById(courseId);
        log.info("Course deleted successfully");

        ResponseModel<Void> responseModel = new ResponseModel<>();
        responseModel.setStatus(HttpStatus.OK.toString());
        responseModel.setMessage("Course deleted successfully");

        return ResponseEntity.ok(responseModel);
    }
}