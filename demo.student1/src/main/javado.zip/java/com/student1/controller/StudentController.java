package com.student1.controller;

import java.util.List;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.student1.model.Student;
import com.student1.repository.StudentRepository;
import com.student1.response.ResponseModel;
import com.student1.service.StudentService;

import ch.qos.logback.classic.Logger;
import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
@RequestMapping("/api/students")
public class StudentController
{
	private static final Logger logger = (Logger) LoggerFactory.getLogger(CourseController.class);
	
	
	 @Autowired
	    private StudentService studentService;
	 
	 @Autowired
	  	private StudentRepository studentRepository;
	 
//	 @PostMapping("/save")
//	    public ResponseEntity<Student> saveStudent(@RequestBody Student student) {
//	      
//	        Set<Course> courses = new HashSet<>();
//	        Course course1 = new Course();
//	        course1.setCourseName("java");
//	        course1.setCourseFaculty("ravi");
//	        course1.setCourseDuration(4);
//	        courses.add(course1);
//
//	        Course course2 = new Course();
//	        course2.setCourseName("spring boot");
//	        course2.setCourseFaculty("dilip");
//	       // course2.setCourseFee(4000);
//	        course2.setCourseDuration(3);
//	        courses.add(course2);
//
//	        student.setCourses(courses);
//
//	        Student savedStudent = studentService.saveStudent(student);
//	        return ResponseEntity.ok(savedStudent);
//	    }   

	 @PostMapping("/save")
	    public ResponseEntity<ResponseModel<Student>> saveStudent(@RequestBody Student student) {
	        Student savedStudent = studentService.saveStudent(student);
	        log.info("Student saved successfully");

	        ResponseModel<Student> responseModel = new ResponseModel<>();
	        responseModel.setStatus(HttpStatus.OK.toString());
	        responseModel.setMessage("Student saved successfully");
	        responseModel.setData(savedStudent);

	        return ResponseEntity.ok(responseModel);
	    }
	 
//	   @GetMapping("/getAllStudents")
//	    public ResponseEntity<Void> getAllStudents()
//	    {
//		 
//		   studentService.findAll();
//	    	//logger.info("fetched successfully");
//	    	return ResponseEntity.ok().build();
//	    }
	   
//	 @GetMapping("/findAll")
//	    public ResponseEntity<ResponseModel<List<Student>>> getAllStudents() {
//	        List<Student> allStudents = studentService.getAllStudents();
//
//	        ResponseModel<List<Student>> responseModel = new ResponseModel<>();
//	        responseModel.setStatus(HttpStatus.OK.toString());
//	        responseModel.setMessage("Fetched all students successfully");
//	        responseModel.setData(allStudents);
//
//	        return ResponseEntity.ok(responseModel);
//	    }
	 
//	 @GetMapping("/findById/{studentId}")
//	 public ResponseEntity<ResponseModel<Student>> findStudentById(@PathVariable Integer studentId)
//	 {
//		 Student student = studentService.getStudentById(studentId);
//		 ResponseEntity<ResponseModel<Student>> response = new ResponseEntity<>()
//		 return new ResponseEntity<Student>(student,HttpStatus.OK);
//	 }
	
	 
	   
	 	@PutMapping("/{studentId}")
	    public ResponseEntity<ResponseModel<Void>> updateStudent(@PathVariable Integer studentId,
	                                                            @RequestBody Student student) {
	        student.setStudentId(studentId);
	        studentService.saveStudent(student);

	        log.info("Student updated successfully with id: " + studentId);

	        ResponseModel<Void> responseModel = new ResponseModel<>();
	        responseModel.setStatus(HttpStatus.OK.toString());
	        responseModel.setMessage("Student updated successfully");

	        return ResponseEntity.ok(responseModel);
	    }
	 	
	 	@DeleteMapping("/{studentId}")
	    public ResponseEntity<ResponseModel<Void>> deleteStudentById(@PathVariable Integer studentId) {
	        studentService.deleteStudentById(studentId);

	        log.info("Student deleted successfully with id: " + studentId);

	        ResponseModel<Void> responseModel = new ResponseModel<>();
	        responseModel.setStatus(HttpStatus.OK.toString());
	        responseModel.setMessage("Student deleted successfully");

	        return ResponseEntity.ok(responseModel);
	    }

}
