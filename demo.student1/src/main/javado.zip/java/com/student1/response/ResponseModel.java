package com.student1.response;

import java.util.List;

import com.student1.model.Student;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ResponseModel <T>
{
	private String status;
	private String message;
	private T data;

}
