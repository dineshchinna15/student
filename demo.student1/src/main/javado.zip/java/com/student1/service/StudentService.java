package com.student1.service;

import java.util.List;

import com.student1.model.Student;
import com.student1.response.ResponseModel;

public interface StudentService 
{
	 Student saveStudent(Student student);
	 
	 ResponseModel<List<Student>> getAllStudents();
	 
	 Student getStudentById(Integer studentId);
	 
	 Student updateStudent(Student student, Integer studentId);
	 
	 void deleteStudentById(Integer studentId);

	 void findAll();
}
