package com.student1.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.student1.model.Course;
import com.student1.repository.CourseRepository;
import com.student1.response.ResponseModel;
@Service
public class CourseServiceImpl implements CourseService
{
	@Autowired
    private CourseRepository courseRepository;

	@Override
	public ResponseModel<Course> saveCourse(Course course) 
	{
		ResponseModel<Course> responseModel = new ResponseModel<Course>();
		Course save = courseRepository.save(course);
		responseModel.setData(save);
		responseModel.setMessage("course details saved successfully");
		responseModel.setStatus(HttpStatus.OK.toString());
		
		return responseModel;
	}

	@Override
	public ResponseModel<List<Course>> getAllCourses() {
		
		ResponseModel<List<Course>> model = new ResponseModel<List<Course>>();
		List<Course> all = courseRepository.findAll();
		model.setData(all);
		model.setMessage("ok");
		model.setStatus(HttpStatus.OK.toString());
		return model;
	}

	@Override
	public Course updateCourse(Course course, Integer courseId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void deleteCourseById(Integer courseId) {
		courseRepository.deleteById(courseId);
		
	}

	@Override
	public List<Course> findAll()
	{
		return (List<Course>)
				courseRepository.findAll();
		
	}
	


	@Override
	public List<Course> getCourseById(Integer courseId) {
		
		return null;
	}

	
	
}
	
