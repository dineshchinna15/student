package com.student1.service;

import java.util.List;

import com.student1.model.Course;
import com.student1.model.Student;
import com.student1.response.ResponseModel;

public interface CourseService 
{
	Course saveCourse(Course course);
	
	ResponseModel<List<Course>> getAllCourses();
	 
	
	List<Course> getCourseById(Integer courseId);
	
	Course updateCourse(Course course, Integer courseId);
	
	void deleteCourseById(Integer courseId);

	List<Course> findAll();

}
