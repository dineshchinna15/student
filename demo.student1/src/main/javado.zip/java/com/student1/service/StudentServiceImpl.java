package com.student1.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.student1.model.Student;
import com.student1.repository.StudentRepository;
import com.student1.response.ResponseModel;
@Service
public class StudentServiceImpl implements StudentService 
{
	@Autowired
	private StudentRepository studentRepository;

	@Override
	public Student saveStudent(Student student) 
	{
		
		return studentRepository.save(student);
	}

	@Override
	public ResponseModel<List<Student>> getAllStudents() {
		
		ResponseModel<List<Student>> model = new ResponseModel<List<Student>>();
		List<Student> all = studentRepository.findAll();
		
		model.setData(all);
		model.setMessage("");
		model.setStatus(HttpStatus.OK.toString());
		
		return model;
		
	}

	@Override
	public Student updateStudent(Student student, Integer studentId) {
		return null;
	}

	@Override
	public void deleteStudentById(Integer studentId) {
		studentRepository.deleteById(studentId);
		
		
		
	}

	@Override
	public Student getStudentById(Integer studentId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void findAll() {
		// TODO Auto-generated method stub
		
	}

	
 

  
}
